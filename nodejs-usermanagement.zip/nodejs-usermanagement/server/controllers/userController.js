const e = require('express');
const mysql = require('mysql')

// Connection Pool to mysql
const pool = mysql.createPool({
    connectionLimit: 100,
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASS,
    database: process.env.DB_NAME
})

// view users
exports.view = (req, res) => {
    // Connect to Database
    pool.getConnection((err, connection) => {
        if (err) throw err; // not connected
        console.log("Connected as ID " + connection.threadId)

        // use the connection
        sqlQuery = "SELECT * FROM users WHERE status='Active'"
        connection.query(sqlQuery, (err, rows) => {
            // when done with the connection, release it
            connection.release()

            if (!err) {
                let removedUser = req.query.removed
                res.render('home', { rows, removedUser }) // this will send data to home page
            } else {
                console.log(err)
            }
            console.log('The Data from user table: \n', rows)
        })
    })
}


// Find user by search
exports.find = (req, res) => {
    // Connect to Database
    pool.getConnection((err, connection) => {
        if (err) throw err; // not connected
        console.log("Connected as ID " + connection.threadId)
        
        // fetch text from search box
        let searchTerm = req.body.search

        // use the connection
        sqlQuery = "SELECT * FROM users WHERE first_name LIKE ? OR last_name LIKE ? OR email LIKE ? OR phone LIKE ?" 
        connection.query(sqlQuery, ['%' + searchTerm + '%', '%' + searchTerm + '%', '%' + searchTerm + '%', '%' + searchTerm + '%'] ,(err, rows) => {
            // when done with the connection, release it
            connection.release()

            if (!err) {
                res.render('home', { rows }) // this will send data to home page
            } else {
                console.log(err)
            }
            console.log('The Data from user table: \n', rows)
        })
    })
}

exports.form = (req, res) =>{
    res.render("add-user")
}

exports.create = (req, res) =>{
    // res.render('add-user')

    // name as per html form
    const { firstName, lastName, email, phone, comments} = req.body

    // Connect to Database
     pool.getConnection((err, connection) => {
        if (err) throw err; // not connected
        console.log("Connected as ID " + connection.threadId)
        
        // use the connection
        sqlQuery = "INSERT users SET first_name = ?, last_name = ?, email = ?, phone = ?, comments = ?, status = 'Active'" 
        connection.query(sqlQuery, [firstName, lastName, email, phone, comments],(err, rows) => {
            // when done with the connection, release it
            connection.release()

            if (!err) {
                res.render('add-user', { alert: 'User Added Successfully' }) // this will send data to home page
            } else {
                console.log(err)
            }
            console.log('The Data from user table: \n', rows)
        })
    })
}

// Edit user
exports.edit = (req, res) => {
    // res.render("edit-user")

    // Connect to Database
    pool.getConnection((err, connection) => {
        if (err) throw err; // not connected
        console.log("Connected as ID " + connection.threadId)

        // use the connection
        sqlQuery = "SELECT * FROM users WHERE id = ?"
        connection.query(sqlQuery, [req.params.id], (err, rows) => {
            // when done with the connection, release it
            connection.release()

            if (!err) {
                res.render('edit-user', { rows }) // this will send data to home page
            } else {
                console.log(err)
            }
            console.log('The Data from user table: \n', rows)
        })
    })
}

// Update user
exports.update = (req, res) => {
    // res.render("edit-user")

    
    // name as per html form
    const { firstName, lastName, email, phone, comments} = req.body

    // Connect to Database
    pool.getConnection((err, connection) => {
        if (err) throw err; // not connected
        console.log("Connected as ID " + connection.threadId)

        // use the connection
        sqlQuery = "UPDATE users SET first_name = ?, last_name = ?, email = ?, phone = ?, comments = ?, status = 'Active' WHERE id = ?"
        connection.query(sqlQuery, [firstName, lastName, email, phone, comments, req.params.id], (err, rows) => {
            // when done with the connection, release it
            connection.release()

            if (!err) {

                pool.getConnection((err, connection) => {
                    if (err) throw err; // not connected
                    console.log("Connected as ID " + connection.threadId)
            
                    // use the connection
                    sqlQuery = "SELECT * FROM users WHERE id = ?"
                    connection.query(sqlQuery, [req.params.id], (err, rows) => {
                        // when done with the connection, release it
                        connection.release()
            
                        if (!err) {
                            res.render('edit-user', { rows, alert:'User updated Successfully'}) // this will send data to home page
                        } else {
                            console.log(err)
                        }
                        console.log('The Data from user table: \n', rows)
                    })
                })
                // res.render('edit-user', { rows }) // this will send data to home page
            } else {
                console.log(err)
            }
            console.log('The Data from user table: \n', rows)
        })
    })
}


// Delete user
exports.delete = (req, res) => {
    // Connect to Database
    pool.getConnection((err, connection) => {
        if (err) throw err; // not connected
        console.log("Connected as ID " + connection.threadId)
        
        // fetch text from search box
        let searchTerm = req.body.search

        // use the connection
        sqlQuery = "UPDATE users SET status = 'Inactive' WHERE id = ?" 
        connection.query(sqlQuery, [req.params.id] ,(err, rows) => {
            // when done with the connection, release it
            connection.release()

            if (!err) {
                let removedUser = encodeURIComponent('User Deleted Successfully')
                // res.render('home', { rows }) // this will send data to home page
                res.redirect("/?removed="+ removedUser)
            } else {
                console.log(err)
            }
            console.log('The Data from user table: \n', rows)
        })
    })
}



// Find user by search
exports.find = (req, res) => {
    // Connect to Database
    pool.getConnection((err, connection) => {
        if (err) throw err; // not connected
        console.log("Connected as ID " + connection.threadId)
        
        // fetch text from search box
        let searchTerm = req.body.search

        // use the connection
        sqlQuery = "SELECT * FROM users WHERE first_name LIKE ? OR last_name LIKE ? OR email LIKE ? OR phone LIKE ?" 
        connection.query(sqlQuery, ['%' + searchTerm + '%', '%' + searchTerm + '%', '%' + searchTerm + '%', '%' + searchTerm + '%'] ,(err, rows) => {
            // when done with the connection, release it
            connection.release()

            if (!err) {
                res.render('home', { rows }) // this will send data to home page
            } else {
                console.log(err)
            }
            console.log('The Data from user table: \n', rows)
        })
    })
}

exports.form = (req, res) =>{
    res.render("add-user")
}


// Create new user
exports.create = (req, res) =>{
    // res.render('add-user')

    // name as per html form
    const { firstName, lastName, email, phone, comments} = req.body

    // Connect to Database
     pool.getConnection((err, connection) => {
        if (err) throw err; // not connected
        console.log("Connected as ID " + connection.threadId)
        
        // use the connection
        sqlQuery = "INSERT users SET first_name = ?, last_name = ?, email = ?, phone = ?, comments = ?, status = 'Active'" 
        connection.query(sqlQuery, [firstName, lastName, email, phone, comments],(err, rows) => {
            // when done with the connection, release it
            connection.release()

            if (!err) {
                res.render('add-user', { alert: 'User Added Successfully' }) // this will send data to home page
            } else {
                console.log(err)
            }
            console.log('The Data from user table: \n', rows)
        })
    })
}

// View user
exports.viewuser = (req, res) => {
    // res.render("edit-user")

    // Connect to Database
    pool.getConnection((err, connection) => {
        if (err) throw err; // not connected
        console.log("Connected as ID " + connection.threadId)

        // use the connection
        sqlQuery = "SELECT * FROM users WHERE id = ?"
        connection.query(sqlQuery, [req.params.id], (err, rows) => {
            // when done with the connection, release it
            connection.release()

            if (!err) {
                res.render('view-user', { rows }) // this will send data to home page
            } else {
                console.log(err)
            }
            console.log('The Data from user table: \n', rows)
        })
    })
}